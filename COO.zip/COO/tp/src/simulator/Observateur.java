package simulator;

public interface Observateur {

	public void update(Observable observable ,double value);

}
